/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package todolist_zyrus;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
/**
 *
 * @author Zyrus
 */
public class ToDoList {
    static Scanner scanner = new Scanner(System.in);
    static ArrayList<jadwal> listjadwal = new ArrayList<>();
    static int nextid = 1;
    
    static class jadwal {
        int id;
        String nama_kegiatan;
        String hari;
        String tanggal;
        int prioritas;

        jadwal(int id, String nama_kegiatan, String hari, String tanggal, int prioritas) {
            this.id = id;
            this.nama_kegiatan = nama_kegiatan;
            this.hari = hari;
            this.tanggal = tanggal;
            this.prioritas = prioritas;
    }
}

public static void main(String[] args) {
    System.out.println("Selamat Datang, Ayo Buat To-Do List Kegiatan mu!");
    
    while (true){
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, dd-MM-yyyy", new Locale("id", "ID"));
        String tanggalSekarang = today.format(formatter);
        
        System.out.println("\nHari ini: " + tanggalSekarang);
        System.out.println("=== MENU ToDoList ===");
        System.out.println("1. Melihat Jadwal");
        System.out.println("2. Menambah Jadwal");
        System.out.println("3. Mengedit Jadwal");
        System.out.println("4. Menghapus Jadwal");
        System.out.println("5. Keluar");
        System.out.print("Pilih menu: ");
        int menu = scanner.nextInt();
        scanner.nextLine();
        
        switch (menu){
            case 1:
                lihat_jadwal();
                break;
            case 2:
                tambah_jadwal();
                break;
            case 3:
                edit_jadwal();
                break;
            case 4:
                hapus_jadwal();
                break;
            case 5:
                System.out.println("Terimakasih, Semoga Harimu Menyenangkan!");
                return;
            default:
                System.out.println("Pilihanmu Tidak Valid.");
                
        }
    }
}

// ============= FORMAT PRIORITAS ============= 
static String formatPrioritas(int p){
    switch (p){
        case 1: return "Tinggi";
        case 2: return "Sedang";
        case 3: return "Rendah";
        default: return "Pilihan Tidak Tersedia";
    }
}

// ============= MELIHAT JADWAL =============
static void lihat_jadwal() {
    if (listjadwal.isEmpty()){
        System.out.println("Belum ada jadwal yang tersimpan, silahkan tambahkan jadwal.");
    } else {
        System.out.println("\n=== Daftar ToDoList Kamu ===");
        for (jadwal j : listjadwal){
            System.out.println("ID: " + j.id);
            System.out.println("Kegiatanmu: " + j.nama_kegiatan);
            System.out.println("Hari: " + j.hari);
            System.out.println("Tanggal: " + j.tanggal);
            System.out.println("Prioritas: " + formatPrioritas(j.prioritas));
            System.out.println("------------------------------------");
        }
    }
}

// ============= MENAMBAH JADWAL =============
static void tambah_jadwal(){
    System.out.println("Nama Kegiatan: ");
    String nama = scanner.nextLine();
    System.out.println("Hari: ");
    String hari = scanner.nextLine();
    System.out.println("Tanggal (dd-mm-yyyy): ");
    String tanggal = scanner.nextLine();
    System.out.println("Prioritas (1=Tinggi, 2=Sedang, 3=Rendah): ");
    int prioritas = scanner.nextInt();
    scanner.nextLine();
    
    jadwal baru = new jadwal(nextid++, nama, hari, tanggal, prioritas);
    listjadwal.add(baru);
    System.out.println("Jadwal Berhasil Ditambahkan!");
}

// ============= MENGEDIT JADWAL =============
static void edit_jadwal(){
    System.out.println("Input ID yang ingin diedit: ");
    int id = scanner.nextInt();
    scanner.nextLine();
    
    jadwal target = null;
    for (jadwal j : listjadwal){
        if (j.id == id){
            target = j;
            break;
        }
    }
    if (target == null){
        System.out.println("Jadwal dengan ID" + id + " Tidak ditemukan! ");
        return;
    }
    System.out.println("\nUpdate Kegiatan Anda: ");
    System.out.print("Nama Kegiatan: ");
    target.nama_kegiatan = scanner.nextLine();
    System.out.print("Hari: ");
    target.hari = scanner.nextLine();
    System.out.print("Tanggal (dd-MM-yyyy): ");
    target.tanggal = scanner.nextLine();
    System.out.print("Prioritas (1=Tinggi, 2=Sedang, 3=Rendah): ");
    target.prioritas = scanner.nextInt();
    scanner.nextLine();

    System.out.println("Jadwal berhasil diperbarui!");
}

// ============= MENGHAPUS JADWAL =============
static void hapus_jadwal(){
    System.out.print("Input ID yang ingin dihapus: ");
    int id = scanner.nextInt();
    scanner.nextLine();
    
    for (jadwal j : listjadwal){
        if (j.id == id){
            listjadwal.remove(j);
            System.out.println("Jadwal dengan ID" + id + " Berhasil dihapus! ");
            return;
        }
    }
    System.out.println("Jadwal dengan ID" + id + " Tidak ditemukan! ");
}
}